# Assets

Place original character sprites, icons, sound effects, and theme artwork here.
Use assets you created yourself or have permission to distribute.
